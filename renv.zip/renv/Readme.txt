Please follow the instructions below for working scenarios.  Please note that the instructions provided are for window OS

1.  Unzip the folder and copy it to location of your choice (For Ex:- Desktop)
2.  open your command prompt in adminstrator mode
3.  Navigate to the folder by typing "cd $your-location-path" and hit enter key
4.  Navigate to virtual env folder by typing "cd renv" and hit enter key
5.  Navigate to scripts folder to activate the virtual environment by typing "cd scripts" and hit enter key
6.  Type the command "activate" and hit enter key.  This should activate the virtual envt
7.  come out of scripts folder by typing "cd.." and hit enter key
9.  Navigate to project folder by typing "cd origin" and hit enter key
10. Type the command "python manage.py runserver".  This should run the server without any issues.
11. open any browser (for ex:- chrome)
12. In the address bar type the server url "http://127.0.0.1:8000/bonds/"
13. It should display a "Rest Framework API root page"
14. Click on "Login" button in the extreme right top corner
15. It should give the login screen
16. Please provide the credentials as below 

	To login as superuser
		username: originadmin
		password: superuser

	To login as normaluser1
		username: originemp1
		password: normaluser1

	To login as normaluser2
		username: originemp2
		password: normaluser2

-------------------------------------------
Functional testing with existing data (GET):
-------------------------------------------
	
17. Some data is already created under each user.
18. The functionality is provided in such a way that all the data created by any user will be visible to "superuser" whereas other users can only view the data created      by them

19. For convenience the field "created_by" is exposed in the UI to verify the above mentioned functionality
20. Furthermore, simple filters are provided on the fields "isin", "lei", "legal_name".  
21. The filters functionality can be verified by clicking on the "Filters" button


---------------------------------------------
Functional testing to create new data (POST):
--------------------------------------------- 
22. Scroll down to bottom of the screen where the UI allows the logged user to "POST" new data in either "HTML" or "Raw Json" format.  The fields "legal_name" and     "created_by" should be left blank.  These fields are exposed for display purposes only

---------------------------------------------
To verify the functionality as new user:
--------------------------------------------- 
23. Type the url "http://127.0.0.1:8000/admin" in the browser and login as "superuser"
24. Click on "Users" hyperlink.  It should navigate to users page
25. Click on "Add User" button on the top right corner to create a new user
26. Click on "Save" button to save the user details
27. logout and login with the credentials of newly created user to verify the functionality.