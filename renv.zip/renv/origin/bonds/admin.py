from django.contrib import admin
from .models import Bond

# Register your models here.
admin.site.register(Bond)
