from django.apps import AppConfig


class BondsConfig(AppConfig):
    name = 'bonds'
