from django.db import models
import requests

# Create your models here.
class Bond(models.Model):

    #Below are the list of columns that are required to store the details of
    #bonds in the table
    isin = models.CharField(max_length=100)
    size = models.IntegerField()
    currency = models.CharField(max_length = 10)
    maturity = models.DateField()
    lei = models.CharField(max_length=100)
    legal_name = models.CharField(max_length=100, blank=True)
    created_by = models.CharField(max_length=20, blank=True)

    def __str__(self):
        return (self.legal_name)

    '''
    This method is created to fetch the legal name of the Bond from the external API.
    This method is invoked while saving the Bond record and it expects a proper "LEI" value 
    is provided by the user while creating the record   
    '''
    def get_legal_name(self):
        try:
            apistring = "https://api.gleif.org/api/v1/lei-records?filter[lei]="
            url = apistring + self.lei
            req = requests.get(url).json()
            legal_name = req['data'][0]['attributes']['entity']['legalName']['name']
        except Exception:
            legal_name = 'Data Not Found'
        return legal_name

    #Overrided "save" method which internally calls an external api via "get_legal_name" method
    #The fetched value will be stored in the column "legal_name" of the table(Model) "Bond" which is
    #created above
    def save(self, *args, **kwargs):
        self.legal_name = self.get_legal_name()
        super(Bond, self).save(*args, **kwargs)


