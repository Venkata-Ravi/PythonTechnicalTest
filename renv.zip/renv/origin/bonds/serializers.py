from .models import Bond
from rest_framework import serializers
from django.contrib.auth import get_user_model

#This serializer is used to create/register the new user
#so that any external person want to use our api,
#the system should force them to register.  Once done
# they should login to create the Bond records
class UserSerializer(serializers.ModelSerializer):
    password = serializers.CharField(write_only=True)

    def create(self, validated_data):
        user = get_user_model().objects.create(
            username = validated_data(['username'])
        )
        user.set_password(validated_data['password'])
        user.save()
        return user

    class Meta:
        model = get_user_model()
        fields = ('username', 'password')

#This is Bondserializer which is created to disply the Bond records
#As per the given task, not much functionality required to be handles in
# this serializer.  Hence kept it simple
class BondSerializers(serializers.ModelSerializer):
    class Meta:
        model = Bond
        fields = ('isin', 'size', 'currency', 'maturity', 'lei', 'legal_name', 'created_by')

