from django.shortcuts import render
from rest_framework import viewsets
from .serializers import BondSerializers, UserSerializer
from .models import Bond
from rest_framework import filters
from rest_framework.permissions import IsAuthenticated, AllowAny
from django_filters.rest_framework import DjangoFilterBackend
from django.contrib.auth import get_user_model
from rest_framework.generics import CreateAPIView

# Create your views here.
#This view is created to deal with the functionality of the Bonds
#It performs the following funtionalities
# The class method "perform_create" is used to set the logged in
# user's name to the column "created_by"
# The class method "get_queryset" is overrided to handle the
# functionality of visibility of date.  This will restrict the logged
# in user to view only the records that were created by him.  In case,
# if the user is super user then all the records will be displayed
# Filters were imported and filter fields were added to support the
# filtering functionality.

class BondViewSet(viewsets.ModelViewSet):
    permission_classes = (IsAuthenticated,)
    serializer_class = BondSerializers
    model = Bond

    def get_queryset(self,username=None):
        if (self.request.user.is_superuser):
            return Bond.objects.all()
        return Bond.objects.filter(created_by=self.request.user)
    

    def perform_create(self, serializer):
        serializer.save(created_by=self.request.user)

    filter_backends = (DjangoFilterBackend,)
    filter_fields = ('isin','lei','legal_name')

class CreateUserView(CreateAPIView):
    model = get_user_model()
    permission_classes = (AllowAny,)
    serializer_class = UserSerializer
